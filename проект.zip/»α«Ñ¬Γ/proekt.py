import turtle
import math
from time import sleep
import os
import random

# Настройка экрана
screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Солнечная система")
screen.setup(800, 800)
screen.tracer(0)

# Создаем папку для изображений, если её нет
if not os.path.exists("images"):
    os.makedirs("images")

# Загружаем изображения планет
planet_images = {
    "Солнце": "images/sun.gif",
    "Меркурий": "images/mercury.gif",
    "Венера": "images/venus.gif",
    "Земля": "images/earth.gif",
    "Марс": "images/mars.gif",
    "Юпитер": "images/jupiter.gif",
    "Сатурн": "images/saturn.gif",
    "Уран": "images/uran.gif",
    "Нептун": "images/neptune.gif"
}

# Регистрируем изображения
for planet_name, image_path in planet_images.items():
    if os.path.exists(image_path):
        screen.register_shape(image_path)
        print(f"Изображение загружено: {planet_name} - {image_path}")
    else:
        print(f"Ошибка: изображение не найдено: {planet_name} - {image_path}")

# Информация о планетах
planet_info = {
    "Солнце": "Звезда в центре Солнечной системы\nДиаметр: 1 392 000 км\nТемпература поверхности: 5500°C",
    "Меркурий": "Самая маленькая планета\nРасстояние от Солнца: 58 млн км\nПериод обращения: 88 дней",
    "Венера": "Самая горячая планета\nРасстояние от Солнца: 108 млн км\nТемпература поверхности: 462°C",
    "Земля": "Наша планета\nРасстояние от Солнца: 150 млн км\nЕдинственная с жидкой водой на поверхности",
    "Марс": "Красная планета\nРасстояние от Солнца: 228 млн км\nИмеет два спутника",
    "Юпитер": "Крупнейшая планета\nРасстояние от Солнца: 778 млн км\nИмеет Большое Красное Пятно",
    "Сатурн": "Планета с кольцами\nРасстояние от Солнца: 1.4 млрд км\nСостоит в основном из газа",
    "Уран": "Ледяной гигант\nРасстояние от Солнца: 2.9 млрд км\nВращается «лёжа на боку»",
    "Нептун": "Самая дальняя планета\nРасстояние от Солнца: 4.5 млрд км\nСамые сильные ветры в системе"
}

# Создаем класс для информационного окна
class InfoBox(turtle.Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.color("white")
    
    def show_info(self, planet_name, x, y):
        self.clear()
        self.goto(x, y)
        self.write(planet_info[planet_name], align="center", font=("Arial", 12, "normal"))
        screen.update()

info_box = InfoBox()

# Создаем класс для планет
class Planet(turtle.Turtle):
    def __init__(self, name, radius, color, size, speed):
        super().__init__()
        self.name = name
        self.radius = radius  # Радиус орбиты
        self.color(color)
        self.penup()
        
        # Устанавливаем относительные размеры планет
        planet_sizes = {
            "Солнце": 3.0,      # 109 диаметров Земли
            "Меркурий": 0.4,    # 0.38 диаметров Земли
            "Венера": 0.9,      # 0.95 диаметров Земли
            "Земля": 1.0,       # 1 диаметр Земли (базовый размер)
            "Марс": 0.5,        # 0.53 диаметров Земли
            "Юпитер": 2.0,      # 11.2 диаметров Земли
            "Сатурн": 1.8,      # 9.5 диаметров Земли
            "Уран": 1.4,        # 4 диаметра Земли
            "Нептун": 1.3       # 3.9 диаметров Земли
        }
        
        # Устанавливаем размер в зависимости от планеты
        self.shapesize(planet_sizes.get(name, size))
        
        self.angle = 0
        self.speed = speed
        
        # Устанавливаем изображение планеты, если оно доступно
        if name in planet_images and os.path.exists(planet_images[name]):
            self.shape(planet_images[name])
        else:
            self.shape("circle")  # Используем круг, если изображение недоступно
        
        # Создаем надпись с названием планеты
        self.label = turtle.Turtle()
        self.label.hideturtle()
        self.label.penup()
        self.label.color("white")
        
        # Добавляем обработчик клика
        self.onclick(self.show_planet_info)
    
    def show_planet_info(self, x, y):
        info_box.show_info(self.name, self.xcor(), self.ycor() + 50)
    
    def move(self):
        # Вычисляем новые координаты
        x = self.radius * math.cos(math.radians(self.angle))
        y = self.radius * math.sin(math.radians(self.angle))
        self.goto(x, y)
        
        # Обновляем надпись
        self.label.clear()
        self.label.goto(x, y + 20)
        self.label.write(self.name, align="center", font=("Arial", 10, "normal"))
        
        # Увеличиваем угол для следующего кадра
        self.angle += self.speed

# Создаем Солнце
sun = Planet("Солнце", 0, "yellow", 3, 0)

# Создаем планеты (название, радиус орбиты, цвет, размер, скорость)
planets = [
    Planet("Меркурий", 120, "gray", 0.4, 4.1),
    Planet("Венера", 180, "orange", 0.9, 1.6),
    Planet("Земля", 240, "blue", 1, 1),
    Planet("Марс", 300, "red", 0.5, 0.5),
    Planet("Юпитер", 400, "orange", 2, 0.08),
    Planet("Сатурн", 500, "gold", 1.8, 0.03),
    Planet("Уран", 600, "lightblue", 1.4, 0.01),
    Planet("Нептун", 700, "blue", 1.3, 0.006)
]

# Создаем орбиты
for radius in [120, 180, 240, 300, 400, 500, 600, 700]:
    orbit = turtle.Turtle()
    orbit.hideturtle()
    orbit.penup()
    orbit.color("gray")
    orbit.pensize(0.5)
    orbit.goto(0, -radius)
    orbit.pendown()
    orbit.circle(radius)

# Добавляем инструкции
instructions = turtle.Turtle()
instructions.hideturtle()
instructions.penup()
instructions.color("white")
instructions.goto(0, 350)
instructions.write("Нажмите 'q' для выхода\nКликните на планету для информации", 
                  align="center", font=("Arial", 12, "normal"))

# Функция для выхода
def exit_game():
    screen.bye()

screen.onkey(exit_game, "q")
screen.listen()

# Функция для очистки информации
def clear_info(x, y):
    if abs(x) > 450 or abs(y) > 450:  # Клик далеко от планет
        info_box.clear()
        screen.update()

screen.onclick(clear_info)

# Создаем звезды на фоне
class BackgroundStar:
    def __init__(self):
        self.x = random.randint(-400, 400)
        self.y = random.randint(-400, 400)
        self.size = random.uniform(0.05, 0.1)
        self.turtle = turtle.Turtle()
        self.turtle.hideturtle()
        self.turtle.penup()
        self.turtle.color("white")
        self.turtle.shapesize(self.size)
        self.turtle.shape("circle")
    
    def draw(self):
        self.turtle.goto(self.x, self.y)
        self.turtle.showturtle()

# Создаем небольшое количество звезд
background_stars = [BackgroundStar() for _ in range(20)]

# Основной цикл анимации
while True:
    try:
        # Отрисовываем звезды на фоне
        for star in background_stars:
            star.draw()
        
        # Отрисовываем планеты
        for planet in planets:
            planet.move()
        
        screen.update()
        sleep(0.01)
    except turtle.Terminator:
        break
